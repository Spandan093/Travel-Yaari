export const photos = [
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Hill-Stations/AULI.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Historical/Ayodhya/images/Ayodhya.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Historical1/Taj%20Mahal.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Honeymoon/Pahalgam_Valley.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Religious/Mathura/images/10305511Mathura_Kusum_Sarovar_Main.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/Religious/Bodh%20gaya.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/beaches/Baga%20Beach.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/goa/goa10.jpg",
      width: 4,
      height: 3
    },
    {
      src: "https://raw.githubusercontent.com/shsarv/TravelYaari/master/places/goa/goa4.jpg",
      width: 4,
      height: 3
    }
  ];
  